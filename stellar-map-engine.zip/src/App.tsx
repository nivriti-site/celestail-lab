/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Search, Calendar, Clock, MapPin, Download, Star, Info } from 'lucide-react';
import html2canvas from 'html2canvas';
import CelestialMap from './components/CelestialMap';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Location {
  name: string;
  lat: number;
  lon: number;
}

const DEFAULT_LOCATION: Location = {
  name: "Dhaka, Bangladesh",
  lat: 23.8103,
  lon: 90.4125
};

export default function App() {
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState<string>("22:00");
  const [location, setLocation] = useState<Location>(DEFAULT_LOCATION);
  const [searchQuery, setSearchQuery] = useState("");
  const [title, setTitle] = useState("The Stars When You Were Born");
  const [subtitle, setSubtitle] = useState("Dhaka, Bangladesh | 12th May 1998");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<Location[]>([]);
  
  const mapRef = useRef<HTMLDivElement>(null);

  const handleSearch = async () => {
    if (!searchQuery) return;
    setIsSearching(true);
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      if (data && data.length > 0) {
        setSearchResults(data.map((item: any) => ({
          name: item.display_name,
          lat: parseFloat(item.lat),
          lon: parseFloat(item.lon)
        })));
      }
    } catch (error) {
      console.error("Search error:", error);
    } finally {
      setIsSearching(false);
    }
  };

  const selectLocation = (loc: Location) => {
    setLocation(loc);
    setSearchResults([]);
    setSearchQuery("");
    // Update subtitle automatically if it matches the pattern
    const formattedDate = new Date(date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
    setSubtitle(`${loc.name.split(',')[0]}, ${loc.name.split(',').pop()?.trim()} | ${formattedDate}`);
  };

  const handleDownload = async () => {
    if (!mapRef.current) return;
    
    const canvas = await html2canvas(mapRef.current, {
      scale: 3,
      useCORS: true,
      backgroundColor: "#000814",
      logging: false,
    });
    
    const link = document.createElement('a');
    link.download = `stellar-map-${location.name.split(',')[0].toLowerCase()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const combinedDate = new Date(`${date}T${time}:00`);

  return (
    <div className="min-h-screen bg-[#000814] text-slate-100 flex flex-col md:flex-row overflow-hidden">
      {/* Sidebar */}
      <aside className="w-full md:w-96 glass border-r border-slate-800/50 p-6 flex flex-col gap-8 overflow-y-auto z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
            <Star className="w-6 h-6 text-yellow-500" />
          </div>
          <h1 className="text-xl font-serif font-bold tracking-tight text-yellow-500/90">Stellar Engine</h1>
        </div>

        <div className="space-y-6">
          {/* Location Search */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <MapPin className="w-3 h-3" /> Location
            </label>
            <div className="relative">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="Search city..."
                  className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500/50 transition-all"
                />
                <button 
                  onClick={handleSearch}
                  disabled={isSearching}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
                >
                  <Search className="w-4 h-4" />
                </button>
              </div>
              
              {searchResults.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-slate-900 border border-slate-700 rounded-lg shadow-xl max-h-60 overflow-y-auto z-20">
                  {searchResults.map((res, i) => (
                    <button
                      key={i}
                      onClick={() => selectLocation(res)}
                      className="w-full text-left px-4 py-2 text-xs hover:bg-slate-800 border-b border-slate-800 last:border-0 transition-colors"
                    >
                      {res.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <p className="text-[10px] text-slate-500 italic">Current: {location.name}</p>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <Calendar className="w-3 h-3" /> Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <Clock className="w-3 h-3" /> Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500/50"
              />
            </div>
          </div>

          {/* Custom Text */}
          <div className="space-y-4 pt-4 border-t border-slate-800/50">
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">Map Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500/50"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">Map Subtitle</label>
              <input
                type="text"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500/50"
              />
            </div>
          </div>
        </div>

        <div className="mt-auto pt-6">
          <button
            onClick={handleDownload}
            className="w-full bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400 text-slate-900 font-bold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-yellow-500/20 active:scale-95"
          >
            <Download className="w-5 h-5" />
            Download for Print
          </button>
          <p className="text-[10px] text-center text-slate-500 mt-4 flex items-center justify-center gap-1">
            <Info className="w-3 h-3" /> High-Resolution 3x DPI Export
          </p>
        </div>
      </aside>

      {/* Main Viewport */}
      <main className="flex-1 relative flex items-center justify-center p-8 md:p-12 overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-radial from-blue-900/20 to-transparent pointer-events-none"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-indigo-900/10 rounded-full blur-[120px] pointer-events-none"></div>
        
        {/* Map Container */}
        <div 
          ref={mapRef}
          className="relative flex flex-col items-center justify-center gap-12 p-16 rounded-3xl"
          style={{ background: 'radial-gradient(circle at center, #001d3d 0%, #000814 100%)' }}
        >
          {/* Titles */}
          <div className="text-center space-y-4">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-500/90 tracking-tight">
              {title}
            </h2>
            <div className="h-[1px] w-32 bg-gradient-to-r from-transparent via-yellow-500/50 to-transparent mx-auto"></div>
            <p className="text-lg md:text-xl font-light text-slate-300/80 italic">
              {subtitle}
            </p>
          </div>

          {/* The Map */}
          <div className="relative">
            <CelestialMap 
              date={combinedDate} 
              lat={location.lat} 
              lon={location.lon} 
            />
            
            {/* Compass Points */}
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-yellow-500/40 tracking-[0.5em]">NORTH</div>
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-yellow-500/40 tracking-[0.5em]">SOUTH</div>
            <div className="absolute top-1/2 -left-8 -translate-y-1/2 -rotate-90 text-[10px] font-bold text-yellow-500/40 tracking-[0.5em]">EAST</div>
            <div className="absolute top-1/2 -right-8 -translate-y-1/2 rotate-90 text-[10px] font-bold text-yellow-500/40 tracking-[0.5em]">WEST</div>
          </div>

          {/* Footer Branding */}
          <div className="flex items-center gap-4 text-slate-500/40">
            <div className="h-[1px] w-12 bg-slate-800"></div>
            <span className="text-[10px] uppercase tracking-[0.3em]">Celestial Engine v1.0</span>
            <div className="h-[1px] w-12 bg-slate-800"></div>
          </div>
        </div>
      </main>
    </div>
  );
}

