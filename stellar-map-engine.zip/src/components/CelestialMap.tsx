import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
// @ts-ignore
import Celestial from 'd3-celestial';
import { Loader2 } from 'lucide-react';

interface CelestialMapProps {
  date: Date;
  lat: number;
  lon: number;
  config?: any;
}

const CelestialMap: React.FC<CelestialMapProps> = ({ date, lat, lon, config }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!containerRef.current) return;

    setIsLoading(true);

    // Clear previous map
    containerRef.current.innerHTML = '<div id="celestial-map"></div>';

    const celestialConfig = {
      width: 800,
      projection: "st", // Stereographic
      transform: "equatorial",
      center: [lon, lat],
      orientationfixed: true,
      geopos: [lat, lon],
      follow: "zenith",
      zoomlevel: 1,
      interactive: false,
      form: false,
      location: false,
      controls: false,
      container: "celestial-map",
      datapath: "https://ofrohn.github.io/data/",
      stars: {
        show: true,
        limit: 6,
        colors: true,
        style: { fill: "#ffffff", opacity: 1 },
        names: false,
        size: 4,
        exponent: -0.28,
        data: 'stars.6.json'
      },
      dsos: { show: false },
      constellations: {
        show: true,
        names: true,
        desig: true,
        namestyle: { fill: "#ccccff", align: "left", baseline: "middle", font: ["12px 'Inter'", "normal", "normal"] },
        lines: true,
        linestyle: { stroke: "#cccccc", width: 0.6, opacity: 0.4 },
        bounds: false
      },
      mw: { show: true, style: { fill: "#ffffff", opacity: 0.1 } },
      lines: {
        graticule: { show: true, linestyle: { stroke: "#cccccc", width: 0.6, opacity: 0.2 } },
        equator: { show: false },
        ecliptic: { show: false },
        horizon: { show: true, linestyle: { stroke: "#cccccc", width: 0.8, opacity: 0.5 } }
      },
      background: {
        fill: "transparent",
        stroke: "transparent",
        opacity: 1
      },
      ...config
    };

    // Celestial expects d3 to be global
    (window as any).d3 = d3;
    
    try {
      // Celestial.display is asynchronous in terms of data loading
      Celestial.display(celestialConfig);
      Celestial.date(date);
      
      // We can't easily detect when d3-celestial is done, but we can wait a bit
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 1500);

      return () => clearTimeout(timer);
    } catch (e) {
      console.error("Celestial Map Error:", e);
      setIsLoading(false);
    }
  }, [date, lat, lon, config]);

  return (
    <div className="celestial-container relative w-full aspect-square max-w-[800px] mx-auto group">
      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-[#000814]/80 rounded-full backdrop-blur-sm">
          <Loader2 className="w-12 h-12 text-yellow-500 animate-spin mb-4" />
          <p className="text-yellow-500/80 font-serif italic tracking-widest text-sm">Aligning Stars...</p>
        </div>
      )}

      {/* Main Map Circle */}
      <div 
        ref={containerRef} 
        className="w-full h-full rounded-full border-[12px] border-slate-900 shadow-[0_0_80px_rgba(0,0,0,0.8)] overflow-hidden bg-gradient-to-b from-[#000814] to-[#001d3d] relative"
      >
        <div id="celestial-map" className="w-full h-full"></div>
      </div>

      {/* Elegant Gold Borders */}
      <div className="absolute inset-0 rounded-full border-[2px] border-yellow-500/40 pointer-events-none shadow-[inset_0_0_30px_rgba(234,179,8,0.1)]"></div>
      <div className="absolute inset-[-6px] rounded-full border-[1px] border-yellow-500/20 pointer-events-none"></div>
      <div className="absolute inset-[-12px] rounded-full border-[1px] border-yellow-500/10 pointer-events-none"></div>

      {/* Compass Marks */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-3 bg-yellow-500/50"></div>
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-1 h-3 bg-yellow-500/50"></div>
      <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-1 bg-yellow-500/50"></div>
      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3 h-1 bg-yellow-500/50"></div>
    </div>
  );
};

export default CelestialMap;
